<?php

	session_start();
	
	include "connect.php";
	
	$conn = new mysqli($host, $db_user, $db_password, $db_name);
	$id = 0;
	if(isset($_POST['id'])) 
	{
		
		$id = mysqli_real_escape_string($conn,$_POST['id']);
	}
	if($id>0)
	{
		$check_record = mysqli_query($conn,"SELECT * FROM posts WHERE id_post=$id");
		$total_rows = mysqli_num_rows($check_record);
		if($total_rows>0)
		{
			$query = "DELETE FROM posts WHERE id_post=".$id;
			if(mysqli_query($conn,$query))
			{
				echo 1;
				exit;
			}
			else
			{
				echo 0;
				exit;	
			}
				
			
			
		}
		else {echo 0; exit;}
	}
	echo 0;
	exit;

?>