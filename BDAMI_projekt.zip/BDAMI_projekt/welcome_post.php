<?php


	session_start();
	
	if (!isset($_SESSION['created']))
	{
		header('Location: create_post.php');
		exit();
	}
	else
	{
		unset($_SESSION['created']);
	}
	
	if (isset($_SESSION['e_bot1'])) unset($_SESSION['e_bot1']);
	if (isset($_SESSION['e_content'])) unset($_SESSION['e_content']);
	if (isset($_SESSION['e_title'])) unset($_SESSION['e_title']);
	
?>

<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Post dodany!</title>
	<link rel="stylesheet" href="css/profile.css" type="text/css"/>
</head>

<body>
	
	<h1>Twoje ogłoszenie zostało dodane!</h1><br /><br />
	
	<h3><a href="user_posts.php">Moje ogłoszenia!</a>
	<a href="display_posts.php">Wszystkie ogłoszenia!</a>
	<a href="profile.php">Mój profil!</a> </h3>


</body>
</html>
	
	