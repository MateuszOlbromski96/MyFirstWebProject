<?php

	session_start();
	
	if (isset($_POST['email']))
	{
		//Udana walidacja? Załóżmy, że tak!
		$wszystko_OK=true;
		
		//Sprawdź poprawność nickname'a
		$login = $_POST['login'];
		
		//Sprawdzenie długości nicka
		if ((strlen($login)<3) || (strlen($login)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_login']="Login musi posiadać od 3 do 20 znaków!";
		}
		
		if (ctype_alnum($login)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_login']="Login może składać się tylko z liter i cyfr (bez polskich znaków)";
		}
		
		// Sprawdź poprawność adresu email
		$email = $_POST['email'];
		$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if ((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email))
		{
			$wszystko_OK=false;
			$_SESSION['e_email']="Podaj poprawny adres e-mail!";
		}
		
		//Sprawdź poprawność hasła
		$password1 = $_POST['password1'];
		$password2 = $_POST['password2'];
		
		if ((strlen($password1)<8) || (strlen($password1)>20))
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']="Hasło musi posiadać od 8 do 20 znaków!";
		}
		
		if ($password1!=$password2)
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']="Podane hasła nie są identyczne!";
		}	

		$password_hash = password_hash($password1, PASSWORD_DEFAULT);
		
		$imie = $_POST['imie'];
		$nazwisko = $_POST['nazwisko'];
		$data_urodzenia = $_POST['data_urodzenia'];
		
		//Czy zaakceptowano regulamin?
		
		if (!isset($_POST['regulamin']))
		{
			$wszystko_OK=false;
			$_SESSION['e_regulamin']="Potwierdź akceptację regulaminu!";
		}				
		
		//Captcha
		
		$secret = "6LdyVjweAAAAAGl-ZU_6qsc6zlNaR9bnADTJf_sz";
		
		$check = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
		
		$response = json_decode($check);
		
		if ($response->success==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_bot']="Potwierdź, że nie jesteś botem!";
		}		
		
		
		//Zapamiętaj wprowadzone dane po nieudanej próbie rejestracji
		$_SESSION['fr_login'] = $login;
		$_SESSION['fr_email'] = $email;
		$_SESSION['fr_password1'] = $password1;
		$_SESSION['fr_password2'] = $password2;
		$_SESSION['fr_imie'] = $imie;
		$_SESSION['fr_nazwisko'] = $nazwisko;
		$_SESSION['fr_data_urodzenia'] = $data_urodzenia;
		if (isset($_POST['regulamin'])) $_SESSION['fr_regulamin'] = true;
		
		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			$conn = new mysqli($host, $db_user, $db_password, $db_name);
			if ($conn->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				//Czy email już istnieje w bazie?
				$result = $conn->query("SELECT id_user FROM users WHERE email='$email'");
				
				if (!$result) throw new Exception($conn->error);
				
				$num_mails = $result->num_rows;
				if($num_mails>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_email']="Istnieje już konto przypisane do tego adresu e-mail!";
				}		

				//Czy login jest już zarezerwowany?
				$result = $conn->query("SELECT id_user FROM users WHERE login='$login'");
				
				if (!$result) throw new Exception($conn->error);
				
				$num_logins = $result->num_rows;
				if($num_logins>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_nick']="Istnieje już gracz o takim loginie! Wybierz inny.";
				}
				
				if ($wszystko_OK==true)
				{
					//Wszystkie warunki spełnione, można wstawić nasze konto do bazy danych
					
					if ($conn->query("INSERT INTO users VALUES (NULL, '$login', '$email', '$password_hash', '$imie', '$nazwisko', '$data_urodzenia')"))
					{
						$_SESSION['success']=true;
						header('Location: welcome.php');
					} 
					else
					{
						throw new Exception($conn->error);
					}
					
				}
				
				$conn->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<span style="color:red;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			echo '<br />Treść błędu: '.$e;
		}
		
	}
	
	
?>
<!DOCTYPE HTML>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Rejestracja</title>
	<script src="https://www.google.com/recaptcha/api.js" ></script>
	<link rel="stylesheet" href="css/register.css" type="text/css"/>
	<style>
		.error
		{
			color:red;
			margin-top: 10px;
			margin-bottom: 10px;
		}
	</style>
		
</head>

<body>
	<h1>Zarejestruj się!</h1>
	
	<h3>
		<a href = "display_posts.php">Ogłoszenia</a> 
		<a href = "index.php">Strona główna</a>
	</h3>
		
	<form id='register' method = "post">
	
		Login: <br/> <input type="text" value="<?php
			if (isset($_SESSION['fr_login']))
			{
				echo $_SESSION['fr_login'];
				unset($_SESSION['fr_login']);
			}
		?>" name="login"> <br/>
		
		<?php
		if (isset($_SESSION['e_login']))
		{
			echo '<div class="error">'.$_SESSION['e_login'].'</div>';
			unset($_SESSION['e_login']);
		}
		?>
		
		E-mail:<br/> <input type="text" value="<?php
			if (isset($_SESSION['fr_email']))
			{
				echo $_SESSION['fr_email'];
				unset($_SESSION['fr_email']);
			}
		?>" name="email"> <br/>
		
		<?php
		if (isset($_SESSION['e_email']))
		{
			echo '<div class="error">'.$_SESSION['e_email'].'</div>';
			unset($_SESSION['e_email']);
		}
		?>
		
		Hasło: </br> <input type="password" value="<?php
			if (isset($_SESSION['fr_password1']))
			{
				echo $_SESSION['fr_password1'];
				unset($_SESSION['fr_password1']);
			}
		?>" name="password1"> <br/>
		
		<?php
		if (isset($_SESSION['e_haslo']))
		{
			echo '<div class="error">'.$_SESSION['e_haslo'].'</div>';
			unset($_SESSION['e_haslo']);
		}
		?>
		
		Powtórz Hasło: </br> <input type="password" value="<?php
			if (isset($_SESSION['fr_password2']))
			{
				echo $_SESSION['fr_password2'];
				unset($_SESSION['fr_password2']);
			}
		?>" name="password2"> <br/>
		
		Imie: <br/> <input type="text" value="<?php
			if (isset($_SESSION['fr_imie']))
			{
				echo $_SESSION['fr_imie'];
				unset($_SESSION['fr_imie']);
			}
		?>" name="imie"> <br/>
		
		Nazwisko: <br/> <input type="text" value="<?php
			if (isset($_SESSION['fr_nazwisko']))
			{
				echo $_SESSION['fr_nazwisko'];
				unset($_SESSION['fr_nazwisko']);
			}
		?>" name="nazwisko"> <br/>
		
		Data urodzenia: <br/> <input type="date" value="<?php
			if (isset($_SESSION['fr_data_urodzenia']))
			{
				echo $_SESSION['fr_data_urodzenia'];
				unset($_SESSION['fr_data_urodzenia']);
			}
		?>" name="data_urodzenia"> <br/>
		
		<label>
			<input type="checkbox" name="regulamin" <?php 
			if (isset($_SESSION['fr_regulamin']))
				{
					echo "checked";
					unset($_SESSION['fr_regulamin']);
				}
				?>/>Akceptuję regulamin
		</label>
		
		<?php
			if (isset($_SESSION['e_regulamin']))
			{
				echo '<div class="error">'.$_SESSION['e_regulamin'].'</div>';
				unset($_SESSION['e_regulamin']);
			}
		?>
		
		<div class="g-recaptcha" data-sitekey="6LdyVjweAAAAAPACjRubGf0Xxgenz1wK4IQv9gix"></div>
		
		<?php
			if (isset($_SESSION['e_bot']))
			{
				echo '<div class="error">'.$_SESSION['e_bot'].'</div>';
				unset($_SESSION['e_bot']);
			}
		?>
		
		<input type="submit" value="Zarejestruj" />
		
	</form>
		
</body>
</html>