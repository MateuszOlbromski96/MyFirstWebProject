<?php

	session_start();
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: index.php');
		exit();
	}
	
?>
<!DOCTYPE HTML>
<html lang="pl-PL">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<title>Profil</title>
		<link rel="stylesheet" href="css/profile.css" type="text/css"/>
	</head>

	<body>
<?php

	echo '<h1>Witaj '.$_SESSION["login"].'!</h1>';
	echo '<h2><b> Twoje dane profilowe:<br/></b></h2>';
	echo "<p> Email: ".$_SESSION['email']."<br/></p>";
	echo "<p> Imie: ".$_SESSION['imie']."<br/></p>";
	echo "<p> Nazwisko: ".$_SESSION['nazwisko']."<br/></p>";
	echo "<p> Data urodzenia: ".$_SESSION['data_urodzenia']."<br/></p>";
	
	echo "<h3>
	<a href='display_posts.php'>Przeglądaj ogłoszenia</a>
	<a href='create_post.php'>Dodaj ogłoszenie</a> 
	<a href='user_posts.php'>Twoje ogłoszenia</a>
	<a href='logout.php'> Wyloguj się! </a>
	</h3>"
?>

	
		
<?php
	if(isset($_SESSION['blad']))	echo $_SESSION['blad'];
?>			
	</body>

</html>