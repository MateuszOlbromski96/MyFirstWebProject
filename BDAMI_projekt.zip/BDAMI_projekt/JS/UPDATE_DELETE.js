
	function pageRedirect() {
      window.location.href = "http://bdami179895.cba.pl/BDAMI_projekt/update_post.php";
    } 
		$(document).ready(function()
		{

		 $('.modify').click(function()
		 {
		   
		   
		   // Delete id
		   var modifyid = $(this).data('id');
		   var modifytitle = $(this).data('ptitle');
		   var modifycontent = $(this).data('content');
		   
		   var confirmalert = confirm("Czy na pewno chcesz edytować?");
		   if (confirmalert == true) 
		   {
				  // AJAX Request
				  $.ajax(
				  {
					url: 'update.php',
					type: 'POST',
					data: { id:modifyid,
							ptitle:modifytitle,
							content:modifycontent},
					success: function(response)
					{

					  if(response == 1)
					  {
						pageRedirect();
					  }
					  else
					  {
						alert('Invalid ID.');
					  }

					}
					});
		   }

		 });
		 
 
		 $('.delete').click(function()
		 {
		   
		   
		   // Delete id
		   var deleteid = $(this).data('id');
		   
		   
		   var confirmalert = confirm("Czy na pewno chcesz usunąć posta?");
		   if (confirmalert == true) 
		   {
				  // AJAX Request
				  $.ajax(
				  {
					url: 'delete.php',
					type: 'POST',
					data: { id:deleteid },
					success: function(response)
					{

					  if(response == 1)
					  {
						alert("Post został usunięty!");
						window.location.reload(true);
					  }
					  else
					  {
						alert('Invalid ID.');
					  }

					}
					});
		   }

		 });
		 

});