<?php

	session_start();
	
	if ((isset($_SESSION['zalogowany'])) && ($_SESSION['zalogowany']==true))
	{
		header('Location: profile.php');
		exit();
	}

?>
<!DOCTYPE HTML>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="description" content="Prosty serwis do pisania ogłoszeń na dowolne potrzeby"/>
	<meta name="keywords" content="ogłoszenia,posty,dodaj post,dodaj ogłoszenie, sprawdź,ogłaszamy,bdami projekt,bdami179895" />
	<title>Ogłaszamy!</title>
	<link rel="stylesheet" href="css/index.css" type="text/css"/>
</head>

<body>
	<h1>Ogłaszamy!</h1>
	
	<h3>
		<a href = "display_posts.php">Ogłoszenia</a>		
		<a href = "register.php">Rejestracja</a>
	</h3>
	
	<form id="login" action = "login.php" method = "post">
		
		Login:</br> <input type="text" name = "login"> <br/>
		Hasło:</br> <input type="password" name = "password"> <br/><br/>
		<input type = "submit" value = "Zaloguj"/>
		
	</form>
			
<?php
	if(isset($_SESSION['blad']))	echo $_SESSION['blad'];
?>			
</body>

</html>