<?php

	session_start();
	
	//Sprawdzenie czy użytkownik jest zalogowany
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: index.php');
		exit();
	}
	
	
	
	if(isset($_POST['title']))
	{
		$id_user = $_SESSION['ID_user'];
		
		$title = $_POST['title'];
			
		if ((strlen($title)<3) || (strlen($title)>100))
		{
			$wszystko_OK=false;
			$_SESSION['e_title']="Tytuł musi posiadać od 3 do 100 znaków!";
		}
		//Założenie że się udało
		$wszystko_OK=true;
			
		$content = $_POST['content'];
		
		if((strlen($content))<10 || (strlen($content)>65535))
		{
			$wszystko_OK=false;
			$_SESSION['e_content']="Tekst musi mieć przynajmniej 10 znaków!";
		}
		
		$secret = "6LdyVjweAAAAAGl-ZU_6qsc6zlNaR9bnADTJf_sz";
		
		$check = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
		
		$response = json_decode($check);
		
		if ($response->success==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_bot1']="Potwierdź, że nie jesteś botem!";
		}
		
		//Po sprawdzeniu warunków dodania posta, można przejść do łączęnia z bazą i próbą dodania go do tabeli posts

		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try
		{
			$conn = new mysqli($host, $db_user, $db_password, $db_name);
			if ($conn->connect_errno!=0)
				{
					throw new Exception(mysqli_connect_errno());
				}
			else
			{
				if($wszystko_OK==true)
				{
					if ($conn->query("INSERT INTO posts VALUES (NULL, '$title', '$content',current_timestamp(),'$id_user')"))
					{
						$_SESSION['created']=true;
						header('Location: welcome_post.php');
					}
					else
					{
						throw new Exception($conn->error);
					}
					
				}							
			} 
			$conn->close();
						
		}
		catch (Exception $e)
		{
			echo '<span style="color:red;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			echo '<br />Treść błędu: '.$e;
		}
	}
	

?>

<!DOCTYPE HTML>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Dodaj ogłoszenie</title>
	<link rel="stylesheet" href="css/create.css" type="text/css"/>
	<script src="https://www.google.com/recaptcha/api.js" ></script>
</head>

<body>

	<h3><a href = "profile.php">Powrót do profilu</a> </h3>
	<h1>Dodaj swoje ogłoszenie</h1>
	<div id="post_form">
		<form id="create_post"  method="post">
			<div class="main">
				<input type="text" name = "title" required size="100" maxlength="100" minlength="4" placeholder="tytuł ogłoszenia"> <br/>
				
				<?php
				if (isset($_SESSION['e_title']))
				{
					echo '<div class="error">'.$_SESSION['e_title'].'</div>';
					unset($_SESSION['e_title']);
				}
				?>
				
				<textarea rows="40" cols="100" name="content" required minlength="10" placeholder="Treść ogłoszenia"></textarea> <br/>
				
				<?php
				if (isset($_SESSION['e_content']))
				{
					echo '<div class="error">'.$_SESSION['e_content'].'</div>';
					unset($_SESSION['e_content']);
				}
				?>
			</div>
			<div class="footer">
				<div class="g-recaptcha" data-sitekey="6LdyVjweAAAAAPACjRubGf0Xxgenz1wK4IQv9gix"></div>
				
				<?php
				if (isset($_SESSION['e_bot1']))
				{
					echo '<div class="error">'.$_SESSION['e_bot1'].'</div>';
					unset($_SESSION['e_bot1']);
				}
				?>
				
				
				<input class="add" type = "submit" value = "Dodaj"/>
			</div>
		</form>
	</div>
	
</body>
</html>