<?php

	session_start();
	
	require_once "connect.php";

?>

<!DOCTYPE HTML>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Twoje ogłoszenia</title>
	<link rel="stylesheet" href="css/display.css" type="text/css"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="js/update_delete.js"></script>
</head>

<body>

	<h3><a href = "profile.php">Powrót do profilu</a> </h3>
	
	<div class="head"><h1> Twoje ogłoszenia </h1></div>
<?php
	
$conn = @new mysqli($host, $db_user, $db_password, $db_name);
	 		
	
	$stmt = $conn->prepare("SELECT posts.id_post, posts.title, posts.content, posts.date_created, users.imie, users.nazwisko, users.id_user
	FROM posts 
	INNER JOIN users 
	ON posts.id_user=users.id_user
	WHERE users.id_user =?
	ORDER BY  posts.date_created DESC");
	
	$stmt->bind_param("i",$_SESSION['ID_user']);
	$stmt->execute();
	$stmt->store_result();
	$stmt->bind_result($id_post,$title,$content,$date_created,$imie,$nazwisko,$id_user);
	
	$stmt->fetch();
	$num_rows = $stmt->num_rows;
	
	if($num_rows>0)
	{
		do
		{
			
			$Id_post = $id_post;
			$Title = $title;
			$Content = $content;
			$Date_created = $date_created;
			$Imie = $imie;
			$Nazwisko = $nazwisko;
			$Id_user = $id_user;
			
			
			
			echo "
				<div class='container'>
		
					<div class='header'>
						$title
					</div>
					
					<div class='paragraph'>
						<p>$content</p>
					</div>
					
					<div class='footer'>
						<span class='delete' data-id='$id_post'>USUŃ</span>
						<span class='modify' data-id='$id_post' data-ptitle='$title' data-content='$content'>EDYTUJ</span>
						<h4>Autor: $imie $nazwisko &emsp; $date_created </h4>
					</div>
					
				</div> ";
		}
		while($stmt->fetch());
	}
	else 
	{
		echo "<h2>Nie dodałeś jeszcze żadnego ogłoszenia, jeśli chcesz dodać kliknij <a href='create_post.php'>TUTAJ!</a></h2>";
	}
	
	
	
?>

</body>

</html>	