<?php

	session_start();
	
	if ((!isset($_POST['login'])) || (!isset($_POST['password'])))
	{
		header('Location: index.php');
		exit();
	}
	
	require_once "connect.php";
	
	$conn = @new mysqli($host, $db_user, $db_password, $db_name);
	
	if ($conn->connect_errno!=0)
	{
		echo "Error: ".$conn->connect_errno. "Opis".$conn->connect_error();
	}
	else
	{
		
		$login = $_POST['login'];
		$password = $_POST['password'];

		
		if ($result = @$conn->query(
		sprintf("SELECT * FROM users WHERE login='%s';",
		mysqli_real_escape_string($conn,$login))))
		{
			
			$num_users = $result->num_rows;
			if($num_users>0)
			{
				$row = $result->fetch_assoc();
				
				if (password_verify($password,$row['password']))
				{
					$_SESSION['zalogowany'] = true;
					
					$_SESSION['ID_user'] = $row['ID_user'];
					$_SESSION['login'] = $row['login'];
					$_SESSION['email'] = $row['email'];
					$_SESSION['imie'] = $row['imie'];
					$_SESSION['nazwisko'] = $row['nazwisko'];
					$_SESSION['data_urodzenia'] = $row['data_urodzenia'];
					
					unset($_SESSION['blad']);
					$result->free_result();
					header('Location: profile.php');
				}
				else
				{
					
					$_SESSION['blad'] = '<span style="color:red">Nieprawidłowy login lub hasło!</span>';
					header('Location: index.php');
				}
			}
			else 
			{
				
				$_SESSION['blad'] = '<span style="color:red">Nieprawidłowy login lub hasło!</span>';
				header('Location: index.php');
			}
		}
		
		$conn->close();
	}

?>

