<?php

	session_start();
	
	require_once "connect.php";

	
?>
<!DOCTYPE HTML>
<html lang="pl-PL">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Ogłoszenia</title>
	<link rel="stylesheet" href="css/display.css" type="text/css"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script type="text/javascript" src="js/update_delete.js"></script>
</head>

<body>
			
	<h3><a href = "profile.php">Powrót do profilu</a></h3>
<?php
		
	$conn = @new mysqli($host, $db_user, $db_password, $db_name);
	
	$sql = 'SELECT posts.id_post, posts.title, posts.content, posts.date_created, users.imie, users.nazwisko, posts.id_user 
	FROM posts
	LEFT JOIN users 
	ON posts.id_user=users.id_user
	ORDER BY posts.date_created DESC';
	$stmt = $conn->query($sql);
	$rows = $stmt->fetch_assoc();
	$num_rows = count($rows);
		
	if($num_rows > 0)
	{
		echo "<div class = 'head'><h1>Wszystkie ogłoszenia</h1></div>";
		
		foreach($conn->query($sql) as $row)
		{
			$id_post=$row['id_post'];
			$title=$row['title'];
			$content=$row['content'];
			$date_created=$row['date_created'];
			$imie=$row['imie'];
			$nazwisko=$row['nazwisko'];
			$autor = $row['id_user'];
			echo "
				<div class='container'>
		
					<div class='header' >
					$title
					</div>
					
					<div class='paragraph' >
					<p>$content</p>
					</div>
					
					<div class='footer'>";
					
					if ($autor==$_SESSION['ID_user'])
					{ echo 
					"<span class='delete' data-id='$id_post'>USUŃ</span>
					<span class='modify' data-id='$id_post' data-ptitle='$title' data-content='$content'>EDYTUJ</span>";
					}
					
			   echo "<h4>Autor: $imie $nazwisko &emsp; $date_created</h4>
					</div>
					
				</div> ";	
		}
	}
?>	
</body>
</html>


'
