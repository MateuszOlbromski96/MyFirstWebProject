<?php

	session_start();
	include "connect.php";
	//Sprawdzenie czy użytkownik jest zalogowany
	
	if (!isset($_SESSION['zalogowany']))
	{
		header('Location: index.php');
		exit();
	}
	
	$conn = new mysqli($host, $db_user, $db_password, $db_name);
	$id_post = 0;
	if(isset($_POST['id'])) 
	{
		
		$id_post = mysqli_real_escape_string($conn,$_POST['id']);
	}
	$title = "";
	if(isset($_POST['ptitle']))
	{
		$title = mysqli_real_escape_string($conn,$_POST['ptitle']);
	}
	$content = "";
	if(isset($_POST['content']))
	{
		$content = mysqli_real_escape_string($conn,$_POST['content']);
	}
	$_SESSION['id_post']=$id_post;
	$_SESSION['title']=$title;
	$_SESSION['content']=$content;
	
	echo 1;
	exit();
	
	
	
	

?>







