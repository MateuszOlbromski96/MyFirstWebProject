<?php

	$host = "37.48.121.82";
	$db_user = "BDAMI179895";
	$db_password = "Hwjqpbc12!";
	$db_name = "matolbromski";
?>