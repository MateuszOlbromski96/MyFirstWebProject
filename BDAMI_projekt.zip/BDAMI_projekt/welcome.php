<?php

	session_start();
	
	if (!isset($_SESSION['success']))
	{
		header('Location: index.php');
		exit();
	}
	else
	{
		unset($_SESSION['success']);
	}
	
	//Usuwanie zmiennych pamiętających wartości wpisane do formularza
	if (isset($_SESSION['fr_login'])) unset($_SESSION['fr_login']);
	if (isset($_SESSION['fr_email'])) unset($_SESSION['fr_email']);
	if (isset($_SESSION['fr_password1'])) unset($_SESSION['fr_password1']);
	if (isset($_SESSION['fr_password2'])) unset($_SESSION['fr_password2']);
	if (isset($_SESSION['fr_imie'])) unset($_SESSION['fr_imie']);
	if (isset($_SESSION['fr_nazwisko'])) unset($_SESSION['fr_nazwisko']);
	if (isset($_SESSION['fr_data_urodzenia'])) unset($_SESSION['fr_data_urodzenia']);
	if (isset($_SESSION['fr_regulamin'])) unset($_SESSION['fr_regulamin']);
	
	//Usuwanie błędów rejestracji
	if (isset($_SESSION['e_login'])) unset($_SESSION['e_login']);
	if (isset($_SESSION['e_email'])) unset($_SESSION['e_email']);
	if (isset($_SESSION['e_haslo'])) unset($_SESSION['e_password']);
	if (isset($_SESSION['e_regulamin'])) unset($_SESSION['e_regulamin']);
	if (isset($_SESSION['e_bot'])) unset($_SESSION['e_bot']);
	
?>

<!DOCTYPE HTML>
<html lang="pl">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Witaj na serwisie ogłoszeniowym!</title>
	<link rel="stylesheet" href="css/profile.css" type="text/css"/>
</head>

<body>
	
	<h1>Dziękujemy za rejestrację w serwisie! Możesz już zalogować się na swoje konto!</h1><br /><br />
	
	<h3><a href="index.php">Zaloguj się na swoje konto!</a></h3>
	<br /><br />
<?php

?>

</body>
</html>